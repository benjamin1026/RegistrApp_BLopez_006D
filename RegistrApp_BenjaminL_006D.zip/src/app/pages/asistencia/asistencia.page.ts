import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { FeriadosService } from '../../services/feriados.service';

@Component({
  selector: 'app-asistencia',
  templateUrl: './asistencia.page.html',
  styleUrls: ['./asistencia.page.scss'],
})
export class AsistenciaPage implements OnInit {

  comentarios : any;

  constructor(private menuController: MenuController,
              private feriadosService: FeriadosService) { }

  ngOnInit() {
    this.feriadosService.getTopFeriado().subscribe(resp => {
      console.log('comentarios', resp);
      this.comentarios = resp;
    })
  } 

  mostrarMenu(){
    this.menuController.open('first');
  }

}
