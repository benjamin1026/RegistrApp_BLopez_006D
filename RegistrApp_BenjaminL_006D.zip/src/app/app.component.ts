import { Component } from '@angular/core';

interface Componente{
  icon:string;
  name:string;
  redirecTo:string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor() {}


  componentes: Componente[] = [ 
    {
      icon: 'wifi-outline',
      name: 'Inicio',
      redirecTo: '/inicio',
    },
    {
      icon: 'balloon-outline',
      name: 'Contexto',
      redirecTo: '/contexto',
    },
    {
      icon: 'cloud-done-outline',
      name: 'Asistencia',
      redirecTo: '/asistencia',
    },
    {
      icon: 'aperture-outline',
      name: 'Leer QR',
      redirecTo: '/leer',
    },
    {
      icon: 'glasses-outline',
      name: 'Generar QR',
      redirecTo: '/generar',
    },
    
  ];




}
